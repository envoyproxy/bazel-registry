// Copyright 2018 The Bazel Authors. All rights reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import UIKit

class ViewController: UIViewController {

  @IBOutlet weak var label: UILabel?

  override func viewDidLoad() {
    super.viewDidLoad()
  }

  @IBAction func pressedButton(sender: UIButton) {
    incrementLabel(label: label!)
  }

  func incrementLabel(label: UILabel) {
    let number = Int((label.text)!)
    label.text = String(number! + 1)
  }

}

