# hermetic_android_toolchains

This repo contains hermetic bazel toolchains for the Android SDK and
NDK. This makes bazel automatically download the tools as needed, and
doesn't require that your developers have them installed globally. This
also ensures you will have the exact same version across all your
developers and CI.

## Usage

Add this to your `MODULE.bazel`:

```starlark
bazel_dep(name = "hermetic_android_toolchains", version = "0.0.0", dev_dependency = True)
bazel_dep(name = "rules_android", version = "0.7.3", dev_dependency = True)
bazel_dep(name = "rules_android_ndk", version = "0.1.5", dev_dependency = True)

android = use_extension("@hermetic_android_toolchains//:extensions.bzl", "android", dev_dependency = True)
android.sdk(
    build_tools_version = "37.0.0",
    version = "37.0",
)
android.ndk(version = "r29")
use_repo(android, "androidsdk", "androidndk")

# Make @rules_android's @androidsdk labels resolve to the hermetic SDK.
rules_android_sdk = use_extension("@rules_android//rules/android_sdk_repository:rule.bzl", "android_sdk_repository_extension", dev_dependency = True)

override_repo(rules_android_sdk, "androidsdk")

# Make @rules_android_ndk's @androidndk labels resolve to the hermetic SDK.
rules_android_ndk = use_extension("@rules_android_ndk//:extension.bzl", "android_ndk_repository_extension", dev_dependency = True)

override_repo(rules_android_ndk, "androidndk")

register_toolchains("@androidndk//:all", "@androidsdk//:all", dev_dependency = True)
```

Once you have reviewed and accepted the SDK and NDK licenses, add this
to your `.bazelrc` for the versions of the licenses you accepted:

```
common --repo_env=ACCEPTED_ANDROID_SDK_LICENSE_VERSION=37.0
common --repo_env=ACCEPTED_ANDROID_NDK_LICENSE_VERSION=r29
```

SDK, build-tools, and NDK versions are explicit. Use
`android.ndk(version = "r25c", api_level = ...)` to specify a different
API level for the NDK.

## Downloading emulators

If you'd like to hermetically download and expose emulator tools and
system images, you can add the following to your `MODULE.bazel`:

```bzl
android.emulator(version = "36.6.11")
android.system_image(
    arch = "arm64-v8a",
    version = "28",
)
android.system_image(
    arch = "x86_64",
    version = "28",
)
# Repeat for each system image you want to download
```

Afterwards the downloads are exposed through various `@androidsdk`
labels mirroring what `rules_android` does such as:

```
@androidsdk//:platform-tools/adb
@androidsdk//:emulator
@androidsdk//:emulator_shared_libs
@androidsdk//:emulator_x86_bios
@androidsdk//:mksd
@androidsdk//:qemu2
@androidsdk//:emulator_images_android_28_arm64-v8a  # Version / arch dependent
@androidsdk//:emulator_images_android_28_arm64-v8a_qemu2_extra  # Version / arch dependent
```

## Specifying versions

This repo includes metadata for many Android SDK and NDK versions so you
can specify a well known version in your `MODULE.bazel` file. When there
is a new version that isn't yet supported by this repo, please submit a
PR updating the `versions.json` files with the correct shas.

Until the version you want to use is merged here you can specify the
full details of a SDK / NDK in your `MODULE.bazel`:

```bzl
android.sdk(
    version = "35",
    api_level = "35",
    build_tools_version = "35.0.0",
    build_tools_directory = "35.0.0",
    build_tools_urls = {
        "linux": "https://mirror.example/build-tools-linux.zip",
        "darwin": "https://mirror.example/build-tools-darwin.zip",
        "windows": "https://mirror.example/build-tools-windows.zip",
    },
    build_tools_sha256s = {
        "linux": "...",
        "darwin": "...",
        "windows": "...",
    },
    platform_tools_urls = {
        "linux": "https://mirror.example/platform-tools-linux.zip",
        "darwin": "https://mirror.example/platform-tools-darwin.zip",
        "windows": "https://mirror.example/platform-tools-windows.zip",
    },
    platform_tools_sha256s = {
        "linux": "...",
        "darwin": "...",
        "windows": "...",
    },
    platforms_url = "https://mirror.example/platform-35.zip",
    platforms_sha256 = "...",
)

android.ndk(
    version = "r27d",
    urls = {
        "linux": "https://mirror.example/android-ndk-r27d-linux.zip",
        "darwin": "https://mirror.example/android-ndk-r27d-darwin.zip",
        "windows": "https://mirror.example/android-ndk-r27d-windows.zip",
    },
    sha256s = {
        "linux": "...",
        "darwin": "...",
        "windows": "...",
    },
    strip_prefix = "android-ndk-r27d",
)
```

## `adb` setup

If you want to use the `adb` CLI that comes with the vendored SDK
instead of one installed on the host system, you must tell bazel where
to find it by adding this to your `.bazelrc`:

```
common --enable_platform_specific_config
mobile-install:linux --adb=external/+android+androidsdk_linux/platform-tools/linux/adb
mobile-install:macos --adb=external/+android+androidsdk_darwin/platform-tools/darwin/adb
mobile-install:windows --adb=external/+android+androidsdk_windows/platform-tools/windows/adb.exe
```
