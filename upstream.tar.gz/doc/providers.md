<!-- Generated with Stardoc, Do Not Edit! -->

The providers described below are propagated and required by various Swift
build rules. Clients interested in writing custom rules that interface
with the rules in this package should use these providers to communicate
with the Swift build rules as needed.


On this page:

  * [SwiftBinaryInfo](#SwiftBinaryInfo)
  * [SwiftClangModuleAspectInfo](#SwiftClangModuleAspectInfo)
  * [SwiftFeatureAllowlistInfo](#SwiftFeatureAllowlistInfo)
  * [SwiftInfo](#SwiftInfo)
  * [SwiftOverlayInfo](#SwiftOverlayInfo)
  * [SwiftPackageConfigurationInfo](#SwiftPackageConfigurationInfo)
  * [SwiftProtoCompilerInfo](#SwiftProtoCompilerInfo)
  * [SwiftProtoInfo](#SwiftProtoInfo)
  * [SwiftSymbolGraphInfo](#SwiftSymbolGraphInfo)
  * [SwiftSynthesizedInterfaceInfo](#SwiftSynthesizedInterfaceInfo)
  * [SwiftToolchainInfo](#SwiftToolchainInfo)
  * [SwiftToolsInfo](#SwiftToolsInfo)
  * [create_clang_module_inputs](#create_clang_module_inputs)
  * [create_swift_module_context](#create_swift_module_context)
  * [create_swift_module_inputs](#create_swift_module_inputs)

<a id="SwiftBinaryInfo"></a>

## SwiftBinaryInfo

<pre>
SwiftBinaryInfo(<a href="#SwiftBinaryInfo-cc_info">cc_info</a>, <a href="#SwiftBinaryInfo-swift_info">swift_info</a>)
</pre>

Information about a binary target's module.
`swift_binary` and `swift_compiler_plugin` propagate this provider that wraps
`CcInfo` and `SwiftInfo` providers, instead of propagating them directly, so
that `swift_test` targets can depend on those binaries and test their modules
(similar to what Swift Package Manager allows) without allowing any
`swift_library` to depend on an arbitrary binary.

**FIELDS**

| Name  | Description |
| :------------- | :------------- |
| <a id="SwiftBinaryInfo-cc_info"></a>cc_info |  A `CcInfo` provider containing the binary's code compiled as a static library, which is suitable for linking into a `swift_test` so that unit tests can be written against it. Notably, this `CcInfo`'s linking context does *not* contain the linker flags used to alias the `main` entry point function, because the purpose of this provider is to allow it to be linked into another binary that would provide its own entry point instead.    |
| <a id="SwiftBinaryInfo-swift_info"></a>swift_info |  A `SwiftInfo` provider representing the Swift module created by compiling the target. This is used specifically by `swift_test` to allow test code to depend on the binary's module without making it possible for arbitrary libraries or binaries to depend on other binaries.    |


<a id="SwiftClangModuleAspectInfo"></a>

## SwiftClangModuleAspectInfo

<pre>
SwiftClangModuleAspectInfo()
</pre>

A "marker provider" (i.e., it has no fields) that is always returned when
`swift_clang_module_aspect` is applied to a target.

This provider exists because `swift_clang_module_aspect` cannot advertise that
it returns `SwiftInfo` (since some code paths do not). Users who want to ensure
aspect ordering via the `required_aspect_providers` parameter to their own
`aspect` function can require this provider instead, which
`swift_clang_module_aspect` does advertise.


<a id="SwiftFeatureAllowlistInfo"></a>

## SwiftFeatureAllowlistInfo

<pre>
SwiftFeatureAllowlistInfo(<a href="#SwiftFeatureAllowlistInfo-allowlist_label">allowlist_label</a>, <a href="#SwiftFeatureAllowlistInfo-aspect_ids">aspect_ids</a>, <a href="#SwiftFeatureAllowlistInfo-managed_features">managed_features</a>, <a href="#SwiftFeatureAllowlistInfo-package_specs">package_specs</a>)
</pre>

Describes a set of features and the packages and aspects that are allowed to
request or disable them.

This provider is an internal implementation detail of the rules; users should
not rely on it or assume that its structure is stable.

**FIELDS**

| Name  | Description |
| :------------- | :------------- |
| <a id="SwiftFeatureAllowlistInfo-allowlist_label"></a>allowlist_label |  A string containing the label of the `swift_feature_allowlist` target that created this provider.    |
| <a id="SwiftFeatureAllowlistInfo-aspect_ids"></a>aspect_ids |  A list of strings representing identifiers of aspects that are allowed to request or disable a feature managed by the allowlist, even when the target the aspect is being applied to does not match `package_specs`.    |
| <a id="SwiftFeatureAllowlistInfo-managed_features"></a>managed_features |  A list of strings representing feature names or their negations that packages in the `packages` list are allowed to explicitly request or disable.    |
| <a id="SwiftFeatureAllowlistInfo-package_specs"></a>package_specs |  A list of `struct` values representing package specifications that indicate which packages (possibly recursive) can request or disable a feature managed by the allowlist.    |


<a id="SwiftInfo"></a>

## SwiftInfo

<pre>
SwiftInfo(*, <a href="#SwiftInfo-_init-direct_swift_infos">direct_swift_infos</a>, <a href="#SwiftInfo-_init-modules">modules</a>, <a href="#SwiftInfo-_init-swift_infos">swift_infos</a>)
</pre>

Contains information about the compiled artifacts of a Swift module.

This provider has a custom initializer that will merge the transitive modules of
a list of `SwiftInfo` providers, rather than a separate "merge" function. The
correct signature when _creating_ a new `SwiftInfo` provider is the following:

```build
SwiftInfo(
    direct_swift_infos,
    modules,
    swift_infos,
)
```

where the arguments are:

*   `direct_swift_infos`: A list of `SwiftInfo` providers from dependencies
    whose direct modules should be treated as direct modules in the resulting
    provider, in addition to their transitive modules being merged.
*   `modules`: A list of values (as returned by `create_swift_module_context`)
    that represent Clang and/or Swift module artifacts that are direct outputs
    of the target being built.
*   `swift_infos`: A list of `SwiftInfo` providers from dependencies whose
    transitive modules should be merged into the resulting provider.

When reading an existing `SwiftInfo` provider, it has the two fields described
below.

**CONSTRUCTOR PARAMETERS**

| Name  | Description | Default Value |
| :------------- | :------------- | :------------- |
| <a id="SwiftInfo-_init-direct_swift_infos"></a>direct_swift_infos | A list of `SwiftInfo` providers from dependencies whose direct modules should be treated as direct modules in the resulting provider, in addition to their transitive modules being merged. | `[]` |
| <a id="SwiftInfo-_init-modules"></a>modules | A list of values (as returned by `create_swift_module_context()`) that represent Clang and/or Swift module artifacts that are direct outputs of the target being built. | `[]` |
| <a id="SwiftInfo-_init-swift_infos"></a>swift_infos | A list of `SwiftInfo` providers from dependencies whose transitive modules should be merged into the resulting provider. | `[]` |

**FIELDS**

| Name  | Description |
| :------------- | :------------- |
| <a id="SwiftInfo-direct_modules"></a>direct_modules |  `List` of values returned from `create_swift_module_context`. The modules (both Swift and C/Objective-C) emitted by the library that propagated this provider.    |
| <a id="SwiftInfo-transitive_modules"></a>transitive_modules |  `Depset` of values returned from `create_swift_module_context`. The transitive modules (both Swift and C/Objective-C) emitted by the library that propagated this provider and all of its dependencies.    |


<a id="SwiftOverlayInfo"></a>

## SwiftOverlayInfo

<pre>
SwiftOverlayInfo(<a href="#SwiftOverlayInfo-linking_context">linking_context</a>)
</pre>

Contains additional artifacts from the Swift overlay for a C/Objective-C module
that also need to be propagated to clients of the module for it to work
properly.

**FIELDS**

| Name  | Description |
| :------------- | :------------- |
| <a id="SwiftOverlayInfo-linking_context"></a>linking_context |  `CcLinkingContext`. A linking context that contain object files, linker flags, and additional linker inputs for Swift code that was compiled as an overlay for a C/Objective-C target.    |


<a id="SwiftPackageConfigurationInfo"></a>

## SwiftPackageConfigurationInfo

<pre>
SwiftPackageConfigurationInfo(<a href="#SwiftPackageConfigurationInfo-disabled_features">disabled_features</a>, <a href="#SwiftPackageConfigurationInfo-enabled_features">enabled_features</a>, <a href="#SwiftPackageConfigurationInfo-package_specs">package_specs</a>)
</pre>

Describes a compiler configuration that is applied by default to targets in a
specific set of packages.

This provider is an internal implementation detail of the rules; users should
not rely on it or assume that its structure is stable.

**FIELDS**

| Name  | Description |
| :------------- | :------------- |
| <a id="SwiftPackageConfigurationInfo-disabled_features"></a>disabled_features |  `List` of strings. Features that will be disabled by default on targets in the packages listed in this package configuration.    |
| <a id="SwiftPackageConfigurationInfo-enabled_features"></a>enabled_features |  `List` of strings. Features that will be enabled by default on targets in the packages listed in this package configuration.    |
| <a id="SwiftPackageConfigurationInfo-package_specs"></a>package_specs |  A list of `struct` values representing package specifications that indicate the set of packages (possibly recursive) to which this configuration is applied.    |


<a id="SwiftProtoCompilerInfo"></a>

## SwiftProtoCompilerInfo

<pre>
SwiftProtoCompilerInfo(<a href="#SwiftProtoCompilerInfo-bundled_proto_paths">bundled_proto_paths</a>, <a href="#SwiftProtoCompilerInfo-compile">compile</a>, <a href="#SwiftProtoCompilerInfo-compiler_deps">compiler_deps</a>, <a href="#SwiftProtoCompilerInfo-internal">internal</a>)
</pre>

Provides information needed to generate Swift code from `ProtoInfo` providers

**FIELDS**

| Name  | Description |
| :------------- | :------------- |
| <a id="SwiftProtoCompilerInfo-bundled_proto_paths"></a>bundled_proto_paths |  List of proto paths for which to skip generation because they're built into the modules imported by the generated Swift proto code, e.g., SwiftProtobuf.    |
| <a id="SwiftProtoCompilerInfo-compile"></a>compile |  A function which compiles Swift source files from `ProtoInfo` providers.<br><br>Args:     label: The label of the target for which the Swift files are being generated.     actions: The actions object used to declare the files to be generated and the actions that generate them.     swift_proto_compiler_info: This `SwiftProtoCompilerInfo` provider.     additional_compiler_info: Additional information passed from the target target to the compiler.     proto_infos: The list of `ProtoInfo` providers to compile.     module_mappings: The module_mappings field of the `SwiftProtoInfo` for the target.<br><br>Returns:     A list of .swift Files generated by the compiler.    |
| <a id="SwiftProtoCompilerInfo-compiler_deps"></a>compiler_deps |  List of targets providing SwiftInfo and CcInfo. These are added as dependencies to the swift compile action of the swift_proto_library. Typically these are proto runtime libraries.<br><br>Well Known Types should be added as dependencies of the swift_proto_library targets as needed to avoid compiling them unnecessarily.    |
| <a id="SwiftProtoCompilerInfo-internal"></a>internal |  Opaque struct passing information from the compiler target to the compile function.    |


<a id="SwiftProtoInfo"></a>

## SwiftProtoInfo

<pre>
SwiftProtoInfo(<a href="#SwiftProtoInfo-direct_pbswift_files">direct_pbswift_files</a>, <a href="#SwiftProtoInfo-module_mappings">module_mappings</a>, <a href="#SwiftProtoInfo-module_name">module_name</a>, <a href="#SwiftProtoInfo-pbswift_files">pbswift_files</a>)
</pre>

Propagates Swift-specific information about a `proto_library`.

**FIELDS**

| Name  | Description |
| :------------- | :------------- |
| <a id="SwiftProtoInfo-direct_pbswift_files"></a>direct_pbswift_files |  `list` of `File`s. The Swift source files (e.g. `.pb.swift`) generated from the `ProtoInfo` providers of the direct proto dependencies of the `swift_proto_library` target.    |
| <a id="SwiftProtoInfo-module_mappings"></a>module_mappings |  `list` of `struct`s. Each struct contains `module_name` and `proto_file_paths` fields that denote the transitive mappings from `.proto` files to Swift modules. This allows messages that reference messages in other libraries to import those modules in generated code.    |
| <a id="SwiftProtoInfo-module_name"></a>module_name |  The name of the Swift module compiled from the `swift_proto_library` which produced this provider.    |
| <a id="SwiftProtoInfo-pbswift_files"></a>pbswift_files |  `depset` of `File`s. The Swift source files (e.g. `.pb.swift`) generated from the `ProtoInfo` providers of the direct and transitive transitive proto dependencies of the `swift_proto_library` target.    |


<a id="SwiftSymbolGraphInfo"></a>

## SwiftSymbolGraphInfo

<pre>
SwiftSymbolGraphInfo(<a href="#SwiftSymbolGraphInfo-direct_symbol_graphs">direct_symbol_graphs</a>, <a href="#SwiftSymbolGraphInfo-transitive_symbol_graphs">transitive_symbol_graphs</a>)
</pre>

Propagates extracted symbol graph files from Swift modules.

**FIELDS**

| Name  | Description |
| :------------- | :------------- |
| <a id="SwiftSymbolGraphInfo-direct_symbol_graphs"></a>direct_symbol_graphs |  `List` of `struct`s representing the symbol graphs extracted from the target that propagated this provider. This list will be empty if propagated by a non-Swift target (although its `transitive_symbol_graphs` may be non-empty if it has Swift dependencies).<br><br>Each `struct` has the following fields:<br><br>*   `module_name`: A string denoting the name of the Swift module.<br><br>*   `symbol_graph_dir`: A directory-type `File` containing one or more     `.symbols.json` files representing the symbol graph(s) for the module.    |
| <a id="SwiftSymbolGraphInfo-transitive_symbol_graphs"></a>transitive_symbol_graphs |  `Depset` of `struct`s representing the symbol graphs extracted from the target that propagated this provider and all of its Swift dependencies. Each `struct` has the same fields as documented in `direct_symbol_graphs`.    |


<a id="SwiftSynthesizedInterfaceInfo"></a>

## SwiftSynthesizedInterfaceInfo

<pre>
SwiftSynthesizedInterfaceInfo(<a href="#SwiftSynthesizedInterfaceInfo-direct_modules">direct_modules</a>, <a href="#SwiftSynthesizedInterfaceInfo-transitive_modules">transitive_modules</a>)
</pre>

Propagates synthesized Swift interfaces for modules.

**FIELDS**

| Name  | Description |
| :------------- | :------------- |
| <a id="SwiftSynthesizedInterfaceInfo-direct_modules"></a>direct_modules |  `List` of `struct`s representing the synthesized interfaces for the modules in the target that propagated this provider. This list will be empty if propagated by a target that does not contain any modules that Swift can synthesize an interface for (i.e., C, or Swift itself), but its `transitive_modules` may be non-empty if it has dependencies for which interfaces can be synthesized.<br><br>Each `struct` has the following fields:<br><br>*   `module_name`: A string denoting the name of the module whose interface is     synthesized.<br><br>*   `synthesized_interface`: A `File` containing the synthesized interface.    |
| <a id="SwiftSynthesizedInterfaceInfo-transitive_modules"></a>transitive_modules |  `Depset` of `struct`s representing the synthesized interfaces for the modules in the target that propagated this provider and all of its dependencies. Each `struct` has the same fields as documented in `direct_modules`.    |


<a id="SwiftToolchainInfo"></a>

## SwiftToolchainInfo

<pre>
SwiftToolchainInfo(<a href="#SwiftToolchainInfo-action_configs">action_configs</a>, <a href="#SwiftToolchainInfo-cc_language">cc_language</a>, <a href="#SwiftToolchainInfo-cc_toolchain_info">cc_toolchain_info</a>, <a href="#SwiftToolchainInfo-clang_implicit_deps_providers">clang_implicit_deps_providers</a>,
                   <a href="#SwiftToolchainInfo-const_protocols_to_gather">const_protocols_to_gather</a>, <a href="#SwiftToolchainInfo-cross_import_overlays">cross_import_overlays</a>, <a href="#SwiftToolchainInfo-debug_outputs_provider">debug_outputs_provider</a>,
                   <a href="#SwiftToolchainInfo-developer_dirs">developer_dirs</a>, <a href="#SwiftToolchainInfo-dynamic_runtime_cc_info">dynamic_runtime_cc_info</a>, <a href="#SwiftToolchainInfo-entry_point_linkopts_provider">entry_point_linkopts_provider</a>,
                   <a href="#SwiftToolchainInfo-feature_allowlists">feature_allowlists</a>, <a href="#SwiftToolchainInfo-generated_header_module_implicit_deps_providers">generated_header_module_implicit_deps_providers</a>,
                   <a href="#SwiftToolchainInfo-implicit_deps_providers">implicit_deps_providers</a>, <a href="#SwiftToolchainInfo-implicit_system_modules">implicit_system_modules</a>, <a href="#SwiftToolchainInfo-module_aliases">module_aliases</a>,
                   <a href="#SwiftToolchainInfo-package_configurations">package_configurations</a>, <a href="#SwiftToolchainInfo-requested_features">requested_features</a>, <a href="#SwiftToolchainInfo-root_dir">root_dir</a>, <a href="#SwiftToolchainInfo-static_runtime_cc_info">static_runtime_cc_info</a>,
                   <a href="#SwiftToolchainInfo-swift_worker">swift_worker</a>, <a href="#SwiftToolchainInfo-system_modules">system_modules</a>, <a href="#SwiftToolchainInfo-test_configuration">test_configuration</a>, <a href="#SwiftToolchainInfo-tool_configs">tool_configs</a>,
                   <a href="#SwiftToolchainInfo-unsupported_features">unsupported_features</a>)
</pre>

Propagates information about a Swift toolchain to compilation and linking rules
that use the toolchain.

**FIELDS**

| Name  | Description |
| :------------- | :------------- |
| <a id="SwiftToolchainInfo-action_configs"></a>action_configs |  This field is an internal implementation detail of the build rules.    |
| <a id="SwiftToolchainInfo-cc_language"></a>cc_language |  The `language` that should be passed to `cc_common` APIs that take it as an argument.    |
| <a id="SwiftToolchainInfo-cc_toolchain_info"></a>cc_toolchain_info |  The `cc_common.CcToolchainInfo` provider from the Bazel C++ toolchain that this Swift toolchain depends on.    |
| <a id="SwiftToolchainInfo-clang_implicit_deps_providers"></a>clang_implicit_deps_providers |  A `struct` with the following fields, which represent providers from targets that should be added as implicit dependencies of any precompiled explicit C/Objective-C modules:<br><br>*   `cc_infos`: A list of `CcInfo` providers from targets specified as the     toolchain's implicit dependencies.<br><br>*   `swift_infos`: A list of `SwiftInfo` providers from targets specified as the     toolchain's implicit dependencies.<br><br>For ease of use, this field is never `None`; it will always be a valid `struct` containing the fields described above, even if those lists are empty.    |
| <a id="SwiftToolchainInfo-const_protocols_to_gather"></a>const_protocols_to_gather |  `File`. A JSON file specifying a list of protocols for extraction of conformances' const values.    |
| <a id="SwiftToolchainInfo-cross_import_overlays"></a>cross_import_overlays |  A list of `SwiftCrossImportOverlayInfo` providers whose `SwiftInfo` providers will be automatically injected into the dependencies of Swift compilations if their declaring module and bystanding module are both already declared as dependencies.    |
| <a id="SwiftToolchainInfo-debug_outputs_provider"></a>debug_outputs_provider |  An optional function that provides toolchain-specific logic around the handling of additional debug outputs for `swift_binary` and `swift_test` targets.<br><br>If specified, this function must take the following keyword arguments:<br><br>*   `ctx`: The rule context of the calling binary or test rule.<br><br>It must return a `struct` with the following fields:<br><br>*   `additional_outputs`: Additional outputs expected from the linking action.<br><br>*   `variables_extension`: A dictionary of additional crosstool variables to     pass to the linking action.    |
| <a id="SwiftToolchainInfo-developer_dirs"></a>developer_dirs |  A list of `structs` containing the following fields:<br><br>*   `developer_path_label`: A `string` representing the type of developer path.<br><br>*   `path`: A `string` representing the path to the developer framework.    |
| <a id="SwiftToolchainInfo-dynamic_runtime_cc_info"></a>dynamic_runtime_cc_info |  The `CcInfo` that selects the toolchain's ordinary dynamic Swift runtime, or `None` if the toolchain supplies its runtime through implicit dependencies. Final links select this provider unless `swift.static_stdlib` is enabled; it is not propagated by libraries.    |
| <a id="SwiftToolchainInfo-entry_point_linkopts_provider"></a>entry_point_linkopts_provider |  A function that returns flags that should be passed to the linker to control the name of the entry point of a linked binary for rules that customize their entry point.<br><br>This function must take the following keyword arguments:<br><br>*   `entry_point_name`: The name of the entry point function, as was passed to     the Swift compiler using the `-entry-point-function-name` flag.<br><br>It must return a `struct` with the following fields:<br><br>*   `linkopts`: A list of strings that will be passed as additional linker flags     when linking a binary with a custom entry point.    |
| <a id="SwiftToolchainInfo-feature_allowlists"></a>feature_allowlists |  A list of `SwiftFeatureAllowlistInfo` providers that allow or prohibit packages from requesting or disabling features.    |
| <a id="SwiftToolchainInfo-generated_header_module_implicit_deps_providers"></a>generated_header_module_implicit_deps_providers |  A `struct` with the following fields, which are providers from targets that should be treated as compile-time inputs to actions that precompile the explicit module for the generated Objective-C header of a Swift module:<br><br>*   `cc_infos`: A list of `CcInfo` providers from targets specified as the     toolchain's implicit dependencies.<br><br>*   `swift_infos`: A list of `SwiftInfo` providers from targets specified as the     toolchain's implicit dependencies.<br><br>This is used to provide modular dependencies for the fixed inclusions (Darwin, Foundation) that are unconditionally emitted in those files.<br><br>For ease of use, this field is never `None`; it will always be a valid `struct` containing the fields described above, even if those lists are empty.    |
| <a id="SwiftToolchainInfo-implicit_deps_providers"></a>implicit_deps_providers |  A `struct` with the following fields, which represent providers from targets that should be added as implicit dependencies of any Swift compilation or linking target (but not to precompiled explicit C/Objective-C modules):<br><br>*   `cc_infos`: A list of `CcInfo` providers from targets specified as the     toolchain's implicit dependencies.<br><br>*   `swift_infos`: A list of `SwiftInfo` providers from targets specified as the     toolchain's implicit dependencies.<br><br>For ease of use, this field is never `None`; it will always be a valid `struct` containing the fields described above, even if those lists are empty.    |
| <a id="SwiftToolchainInfo-implicit_system_modules"></a>implicit_system_modules |  A `struct` with in the same shape as `system_modules` for the system modules that every Swift compilation implicitly requires.    |
| <a id="SwiftToolchainInfo-module_aliases"></a>module_aliases |  A `SwiftModuleAliasesInfo` provider that defines the module aliases to use during compilation.    |
| <a id="SwiftToolchainInfo-package_configurations"></a>package_configurations |  A list of `SwiftPackageConfigurationInfo` providers that specify additional compilation configuration options that are applied to targets on a per-package basis.    |
| <a id="SwiftToolchainInfo-requested_features"></a>requested_features |  `List` of `string`s. Features that should be implicitly enabled by default for targets built using this toolchain, unless overridden by the user by listing their negation in the `features` attribute of a target/package or in the `--features` command line flag.<br><br>These features determine various compilation and debugging behaviors of the Swift build rules, and they are also passed to the C++ APIs used when linking (so features defined in CROSSTOOL may be used here).    |
| <a id="SwiftToolchainInfo-root_dir"></a>root_dir |  `String`. The workspace-relative root directory of the toolchain.    |
| <a id="SwiftToolchainInfo-static_runtime_cc_info"></a>static_runtime_cc_info |  A `CcInfo` that selects the static Swift runtime, or `None` if the toolchain does not support static Swift runtime linking. Final links select this provider when `swift.static_stdlib` is enabled; it is not propagated by libraries.    |
| <a id="SwiftToolchainInfo-swift_worker"></a>swift_worker |  `File`. The executable representing the worker executable used to invoke the compiler and other Swift tools (for both incremental and non-incremental compiles).    |
| <a id="SwiftToolchainInfo-system_modules"></a>system_modules |  A `struct` with the following fields, which represent providers from targets that should be added as implicit dependencies of any compilation or linking target:<br><br>*   `cc_infos`: A list of `CcInfo` providers from targets specified as the     toolchain's implicit dependencies.<br><br>*   `swift_infos`: A list of `SwiftInfo` providers from targets specified as the     toolchain's implicit dependencies.<br><br>For ease of use, this field is never `None`; it will always be a valid `struct` containing the fields described above, even if those lists are empty.    |
| <a id="SwiftToolchainInfo-test_configuration"></a>test_configuration |  `Struct` containing the following fields:<br><br>*   `binary_name`: A template string used to compute the name of the output     binary for `swift_test` rules. Any occurrences of the string `"{name}"` will     be substituted by the name of the target.<br><br>*   `env`: A `dict` of environment variables to be set when running tests     that were built with this toolchain.<br><br>*   `execution_requirements`: A `dict` of execution requirements for tests     that were built with this toolchain.<br><br>*   `objc_test_discovery`: A Boolean value indicating whether test targets     should discover tests dynamically using the Objective-C runtime.<br><br>*   `test_linking_contexts`: A list of `CcLinkingContext`s that provide     additional flags to use when linking test binaries.<br><br>This is used, for example, with Xcode-based toolchains to ensure that the `xctest` helper and coverage tools are found in the correct developer directory when running tests.    |
| <a id="SwiftToolchainInfo-tool_configs"></a>tool_configs |  This field is an internal implementation detail of the build rules.    |
| <a id="SwiftToolchainInfo-unsupported_features"></a>unsupported_features |  `List` of `string`s. Features that should be implicitly disabled by default for targets built using this toolchain, unless overridden by the user by listing them in the `features` attribute of a target/package or in the `--features` command line flag.<br><br>These features determine various compilation and debugging behaviors of the Swift build rules, and they are also passed to the C++ APIs used when linking (so features defined in CROSSTOOL may be used here).    |


<a id="SwiftToolsInfo"></a>

## SwiftToolsInfo

<pre>
SwiftToolsInfo(<a href="#SwiftToolsInfo-additional_inputs">additional_inputs</a>, <a href="#SwiftToolsInfo-swift_autolink_extract">swift_autolink_extract</a>, <a href="#SwiftToolsInfo-swift_driver">swift_driver</a>, <a href="#SwiftToolsInfo-swift_symbolgraph_extract">swift_symbolgraph_extract</a>)
</pre>

Propagates information about Swift toolchain tools that can be specified as
labels to pull them into the input root.

This provider allows users to specify Swift toolchain executables as explicit
dependencies, ensuring they are available in the execution environment.

**FIELDS**

| Name  | Description |
| :------------- | :------------- |
| <a id="SwiftToolsInfo-additional_inputs"></a>additional_inputs |  `List` of `File`s. Additional files to add to the action input root when calling these tools.    |
| <a id="SwiftToolsInfo-swift_autolink_extract"></a>swift_autolink_extract |  `File`. The executable that extracts autolink information from object files. This tool is used to determine which libraries need to be linked based on import statements in Swift code.    |
| <a id="SwiftToolsInfo-swift_driver"></a>swift_driver |  `File`. The Swift driver executable that orchestrates compilation and linking operations. This is the main entry point for invoking the Swift compiler toolchain.    |
| <a id="SwiftToolsInfo-swift_symbolgraph_extract"></a>swift_symbolgraph_extract |  `File`. The executable that extracts symbol graph information from Swift modules. This tool generates structured data about APIs, which can be used for documentation generation and other tooling purposes.    |


<a id="create_clang_module_inputs"></a>

## create_clang_module_inputs

<pre>
create_clang_module_inputs(*, <a href="#create_clang_module_inputs-compilation_context">compilation_context</a>, <a href="#create_clang_module_inputs-module_map">module_map</a>, <a href="#create_clang_module_inputs-precompiled_module">precompiled_module</a>, <a href="#create_clang_module_inputs-strict_includes">strict_includes</a>)
</pre>

Creates a value representing a Clang module used as a Swift dependency.

**PARAMETERS**


| Name  | Description | Default Value |
| :------------- | :------------- | :------------- |
| <a id="create_clang_module_inputs-compilation_context"></a>compilation_context |  A `CcCompilationContext` that contains the header files and other context (such as include paths, preprocessor defines, and so forth) needed to compile this module as an explicit module.   |  none |
| <a id="create_clang_module_inputs-module_map"></a>module_map |  The text module map file that defines this module. This argument may be specified as a `File` or as a `string`; in the latter case, it is assumed to be the path to a file that cannot be provided as an action input because it is outside the workspace (for example, the module map for a module from an Xcode SDK).   |  none |
| <a id="create_clang_module_inputs-precompiled_module"></a>precompiled_module |  A `File` representing the precompiled module (`.pcm` file) if one was emitted for the module. This may be `None` if no explicit module was built for the module; in that case, targets that depend on the module will fall back to the text module map and headers.   |  `None` |
| <a id="create_clang_module_inputs-strict_includes"></a>strict_includes |  A `depset` of strings representing additional Clang include paths that should be passed to the compiler when this module is a _direct_ dependency of the module being compiled. May be `None`. **This field only exists to support a specific legacy use case and should otherwise not be used, as it is fundamentally incompatible with Swift's import model.**   |  `None` |

**RETURNS**

A `struct` containing the values provided as arguments.


<a id="create_swift_module_context"></a>

## create_swift_module_context

<pre>
create_swift_module_context(*, <a href="#create_swift_module_context-name">name</a>, <a href="#create_swift_module_context-clang">clang</a>, <a href="#create_swift_module_context-const_gather_protocols">const_gather_protocols</a>, <a href="#create_swift_module_context-compilation_context">compilation_context</a>,
                            <a href="#create_swift_module_context-is_framework">is_framework</a>, <a href="#create_swift_module_context-is_system">is_system</a>, <a href="#create_swift_module_context-label">label</a>, <a href="#create_swift_module_context-swift">swift</a>)
</pre>

Creates a value containing Clang/Swift module artifacts of a dependency.

It is possible for both `clang` and `swift` to be present; this is the case
for Swift modules that generate an Objective-C header, where the Swift
module artifacts are propagated in the `swift` context and the generated
header and module map are propagated in the `clang` context.

Though rare, it is also permitted for both the `clang` and `swift` arguments
to be `None`. One example of how this can be used is to model system
dependencies (like Apple SDK frameworks) that are implicitly available as
part of a non-hermetic SDK (Xcode) but do not propagate any artifacts of
their own. This would only apply in a build using implicit modules, however;
when using explicit modules, one would propagate the module artifacts
explicitly. But allowing for the empty case keeps the build graph consistent
if switching between the two modes is necessary, since it will not change
the set of transitive module names that are propagated by dependencies
(which other build rules may want to depend on for their own analysis).


**PARAMETERS**


| Name  | Description | Default Value |
| :------------- | :------------- | :------------- |
| <a id="create_swift_module_context-name"></a>name |  The name of the module.   |  none |
| <a id="create_swift_module_context-clang"></a>clang |  A value returned by `create_clang_module_inputs` that contains artifacts related to Clang modules, such as a module map or precompiled module. This may be `None` if the module is a pure Swift module with no generated Objective-C interface.   |  `None` |
| <a id="create_swift_module_context-const_gather_protocols"></a>const_gather_protocols |  A list of protocol names from which constant values should be extracted from source code that takes this module as a *direct* dependency.   |  `[]` |
| <a id="create_swift_module_context-compilation_context"></a>compilation_context |  A value returned from `swift_common.create_compilation_context` that contains the context needed to compile the module being built. This may be `None` if the module wasn't compiled from sources.   |  `None` |
| <a id="create_swift_module_context-is_framework"></a>is_framework |  Indictates whether the module is a framework module. The default value is `False`.   |  `False` |
| <a id="create_swift_module_context-is_system"></a>is_system |  Indicates whether the module is a system module. The default value is `False`. System modules differ slightly from non-system modules in the way that they are passed to the compiler. For example, non-system modules have their Clang module maps passed to the compiler in both implicit and explicit module builds. System modules, on the other hand, do not have their module maps passed to the compiler in implicit module builds because there is currently no way to indicate that modules declared in a file passed via `-fmodule-map-file` should be treated as system modules even if they aren't declared with the `[system]` attribute, and some system modules may not build cleanly with respect to warnings otherwise. Therefore, it is assumed that any module with `is_system == True` must be able to be found using import search paths in order for implicit module builds to succeed.   |  `False` |
| <a id="create_swift_module_context-label"></a>label |  The Bazel label of the target that owns the module. This is used to produce actionable diagnostics for Swift layering violations. May be `None` for modules that are not owned by a Bazel target.   |  `None` |
| <a id="create_swift_module_context-swift"></a>swift |  A value returned by `create_swift_module_inputs` that contains artifacts related to Swift modules, such as the `.swiftmodule`, `.swiftdoc`, and/or `.swiftinterface` files emitted by the compiler. This may be `None` if the module is a pure C/Objective-C module.   |  `None` |

**RETURNS**

A `struct` containing the given values provided as arguments.


<a id="create_swift_module_inputs"></a>

## create_swift_module_inputs

<pre>
create_swift_module_inputs(*, <a href="#create_swift_module_inputs-ast_files">ast_files</a>, <a href="#create_swift_module_inputs-const_protocols_to_gather">const_protocols_to_gather</a>, <a href="#create_swift_module_inputs-defines">defines</a>, <a href="#create_swift_module_inputs-generated_header">generated_header</a>,
                           <a href="#create_swift_module_inputs-indexstore">indexstore</a>, <a href="#create_swift_module_inputs-original_module_name">original_module_name</a>, <a href="#create_swift_module_inputs-plugins">plugins</a>, <a href="#create_swift_module_inputs-private_swiftinterface">private_swiftinterface</a>,
                           <a href="#create_swift_module_inputs-swiftdoc">swiftdoc</a>, <a href="#create_swift_module_inputs-swiftinterface">swiftinterface</a>, <a href="#create_swift_module_inputs-swiftmodule">swiftmodule</a>, <a href="#create_swift_module_inputs-swiftsourceinfo">swiftsourceinfo</a>)
</pre>

Creates a value representing a Swift module use as a Swift dependency.

**PARAMETERS**


| Name  | Description | Default Value |
| :------------- | :------------- | :------------- |
| <a id="create_swift_module_inputs-ast_files"></a>ast_files |  A list of `File`s output from the `DUMP_AST` action.   |  `[]` |
| <a id="create_swift_module_inputs-const_protocols_to_gather"></a>const_protocols_to_gather |  A list of protocol names from which constant values should be extracted from source code that takes this module as a *direct* dependency.   |  `[]` |
| <a id="create_swift_module_inputs-defines"></a>defines |  A list of defines that will be provided as `copts` to targets that depend on this module. If omitted, the empty list will be used.   |  `[]` |
| <a id="create_swift_module_inputs-generated_header"></a>generated_header |  A `File` representing the Swift generated header.   |  `None` |
| <a id="create_swift_module_inputs-indexstore"></a>indexstore |  A `File` representing the directory that contains the index store data generated by the compiler if the `"swift.index_while_building"` feature is enabled, otherwise this will be `None`.   |  `None` |
| <a id="create_swift_module_inputs-original_module_name"></a>original_module_name |  The original name of the module if it was changed by a module mapping; otherwise, `None`.   |  `None` |
| <a id="create_swift_module_inputs-plugins"></a>plugins |  A list of `SwiftCompilerPluginInfo` providers representing compiler plugins that are required by this module and should be loaded by the compiler when this module is directly depended on.   |  `[]` |
| <a id="create_swift_module_inputs-private_swiftinterface"></a>private_swiftinterface |  The `.private.swiftinterface` file emitted by the compiler for this module. May be `None` if no private module interface file was emitted.   |  `None` |
| <a id="create_swift_module_inputs-swiftdoc"></a>swiftdoc |  The `.swiftdoc` file emitted by the compiler for this module.   |  none |
| <a id="create_swift_module_inputs-swiftinterface"></a>swiftinterface |  The `.swiftinterface` file emitted by the compiler for this module. May be `None` if no module interface file was emitted.   |  `None` |
| <a id="create_swift_module_inputs-swiftmodule"></a>swiftmodule |  The `.swiftmodule` file emitted by the compiler for this module, or a string path to a system-provided prebuilt `.swiftmodule` file.   |  none |
| <a id="create_swift_module_inputs-swiftsourceinfo"></a>swiftsourceinfo |  The `.swiftsourceinfo` file emitted by the compiler for this module. May be `None` if no source info file was emitted.   |  `None` |

**RETURNS**

A `struct` containing the values provided as arguments.


