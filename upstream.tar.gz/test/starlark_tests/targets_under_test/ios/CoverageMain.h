int coverageFoo(void);
