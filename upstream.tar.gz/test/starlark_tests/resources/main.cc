// Copyright 2021 The Bazel Authors. All rights reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// C++ binary with basic hello world for universal Apple binary tests.

#include <iostream>


#if defined(__x86_64__)
void function_for_x86_64() {
  std::cout << "Compiled for x86_64" << std::endl;
}
#elif defined(__aarch64__)
void function_for_arch64() {
  std::cout << "Compiled for arm64" << std::endl;
}
#endif

int main(int argc, char** argv) {
  return 0;
}
