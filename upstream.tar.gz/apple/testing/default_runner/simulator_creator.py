#!/usr/bin/python3
# Copyright 2022 The Bazel Authors. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import argparse
import json
import os
import random
import string
import subprocess
import sys
import time
from dataclasses import dataclass
from typing import List, Optional


def _simctl(extra_args: List[str]) -> str:
    return subprocess.check_output(["xcrun", "simctl", *extra_args], text=True)


def _boot_simulator(simulator_id: str) -> None:
    # This private command boots the simulator if it isn't already, and waits
    # for the appropriate amount of time until we can actually run tests
    try:
        output = _simctl(["bootstatus", simulator_id, "-b"])
        print(output, file=sys.stderr)
    except subprocess.CalledProcessError as e:
        exit_code = e.returncode

        # When reusing simulators we may encounter the error:
        # 'Unable to boot device in current state: Booted'.
        #
        # This is because the simulator is already booted, and we can ignore it
        # if we check and the simulator is in fact booted.
        if exit_code == 149:
            devices = json.loads(
                _simctl(["list", "devices", "-j", simulator_id]),
            )["devices"]
            device = next(
                (
                    blob
                    for devices_for_os in devices.values()
                    for blob in devices_for_os
                    if blob["udid"] == simulator_id
                ),
                None
            )
            if device and device["state"].lower() == "booted":
                print(
                    f"Simulator '{device['name']}' ({simulator_id}) is already booted",
                    file=sys.stderr,
                )
                exit_code = 0

        # Both of these errors translate to strange simulator states that may
        # end up causing issues, but attempting to actually use the simulator
        # instead of failing at this point might still succeed
        #
        # 164: EBADDEVICE
        # 165: EBADDEVICESTATE
        if exit_code in (164, 165):
            print(
                f"Ignoring 'simctl bootstatus' exit code {exit_code}",
                file=sys.stderr,
            )
        elif exit_code != 0:
            print(f"'simctl bootstatus' exit code {exit_code}", file=sys.stderr)
            raise

    # Add more arbitrary delay before tests run. Even bootstatus doesn't wait
    # long enough and tests can still fail because the simulator isn't ready
    time.sleep(3)


@dataclass
class _Runtime:
    identifier: str
    platform: str
    version: str


def _selected_simulator_runtime(
    os_version: Optional[str], sdk_version: Optional[str]
) -> _Runtime:
    runtimes = json.loads(_simctl(["list", "runtimes", "-j"]))["runtimes"]
    available_runtimes = [
        runtime
        for runtime in runtimes
        if runtime["platform"] == "iOS" and runtime["isAvailable"]
    ]
    if not available_runtimes:
        raise RuntimeError("no available runtimes found")
    sdk_runtime_match = None
    if sdk_version:
        sdk_name = f"iphoneos{sdk_version}"
        sdk_runtime_matches = json.loads(_simctl(["runtime", "match", "list", "-j"]))
        if sdk_name not in sdk_runtime_matches:
            raise RuntimeError(
                f"no sdk build to runtime mapping found matching {sdk_name}"
            )
        sdk_runtime_match = sdk_runtime_matches[sdk_name]
    for runtime in available_runtimes:
        if os_version and runtime["version"] == os_version:
            return _Runtime(
                identifier=runtime["identifier"],
                platform=runtime["platform"],
                version=runtime["version"],
            )
        elif (
            sdk_runtime_match
            and runtime["buildversion"] == sdk_runtime_match["chosenRuntimeBuild"]
        ):
            return _Runtime(
                identifier=runtime["identifier"],
                platform=runtime["platform"],
                version=runtime["version"],
            )
    if sdk_version:
        # `chosenRuntimeBuild` is a preference and is not guaranteed to be
        # installed. Simulator runtimes can be patched independently from
        # Xcode, which changes their build and patch version while preserving
        # the SDK's OS version.
        for runtime in available_runtimes:
            runtime_version = runtime["version"]
            if runtime_version == sdk_version or runtime_version.startswith(f"{sdk_version}."):
                return _Runtime(
                    identifier=runtime["identifier"],
                    platform=runtime["platform"],
                    version=runtime["version"],
                )
    raise RuntimeError("no matching runtimes found")


def _default_device_name(device_type: str, os_version: str) -> str:
    return f"BAZEL_TEST_{device_type}_{os_version}"


def _create_and_boot_simulator(
    device_name: str,
    device_type: str,
    runtime_identifier: str,
    reuse_simulator: bool,
) -> str:
    devices = json.loads(_simctl(["list", "devices", "-j"]))["devices"]
    existing_device = None

    if reuse_simulator:
        devices_for_os = devices.get(runtime_identifier) or []
        existing_device = next(
            (blob for blob in devices_for_os if blob["name"] == device_name), None
        )

    if existing_device:
        simulator_id = existing_device["udid"]
        name = existing_device["name"]
        # If the device is already booted assume that it was created with this
        # script and bootstatus has already waited for it to be in a good state
        # once
        state = existing_device["state"].lower()
        print(f"Existing simulator '{name}' ({simulator_id}) state is: {state}", file=sys.stderr)
        if state != "booted":
            _boot_simulator(simulator_id)
    else:
        if not reuse_simulator:
            # Simulator reuse is based on device name, therefore we must generate a unique name to
            # prevent unintended reuse.
            device_name_suffix = ''.join(random.choices(string.ascii_letters + string.digits, k=8))
            device_name += f"_{device_name_suffix}"

        simulator_id = _simctl(
            ["create", device_name, device_type, runtime_identifier]
        ).strip()
        print(f"Created new simulator '{device_name}' ({simulator_id})", file=sys.stderr)
        _boot_simulator(simulator_id)

    return simulator_id.strip()


class Namespace(argparse.Namespace):
    os_version: Optional[str]
    sdk_version: Optional[str]
    device_type: Optional[str]
    simulator_name: Optional[str]
    reuse_simulator: bool


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--os-version",
        required=False,
        default=None,
        help="The OS version to run the tests on, ex: 12.1",
    )
    parser.add_argument(
        "--sdk-version",
        required=False,
        default=None,
        help="The SDK version the tests were built for, ex: 12.1",
    )
    parser.add_argument(
        "--device-type",
        required=False,
        default=None,
        help="The iOS device to run the tests on, ex: iPhone 15",
    )
    parser.add_argument(
        "--name",
        required=False,
        default=None,
        help="The name to use for the device; default is 'BAZEL_TEST_[device_type]_[os_version]'",
    )
    parser.add_argument(
        "--reuse-simulator",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Toggle simulator reuse; default is True",
    )
    return parser


def _main() -> None:
    parser = _build_parser()

    args = parser.parse_args(namespace=Namespace())

    device_type = args.device_type or os.getenv("SIMULATOR_DEVICE_TYPE")
    if not device_type:
        parser.error(
            "Device type must be provided either as an argument or through the SIMULATOR_DEVICE_TYPE environment variable"
        )

    os_version = args.os_version or os.getenv("SIMULATOR_OS_VERSION")
    sdk_version = args.sdk_version or os.getenv("SIMULATOR_SDK_VERSION")
    reuse_simulator: bool = args.reuse_simulator or (
        os.getenv("SIMULATOR_REUSE_SIMULATOR") is not None
    )

    selected_runtime = _selected_simulator_runtime(os_version, sdk_version)
    device_name = args.name or _default_device_name(
        device_type, selected_runtime.version
    )

    print("Selected simulator runtime", selected_runtime.identifier, file=sys.stderr)

    simulator_id = _create_and_boot_simulator(
        device_name, device_type, selected_runtime.identifier, reuse_simulator
    )

    print(simulator_id.strip())


if __name__ == "__main__":
    _main()
