// Copyright 2019 The Bazel Authors. All rights reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#ifndef BUILD_BAZEL_RULES_SWIFT_TOOLS_COMMON_FILE_SYSTEM_H_
#define BUILD_BAZEL_RULES_SWIFT_TOOLS_COMMON_FILE_SYSTEM_H_

#include <filesystem>
#include <ostream>

#include "absl/strings/string_view.h"

namespace bazel_rules_swift {

// Returns a path suitable for filesystem operations, adding the Windows
// extended-length prefix when necessary.
std::filesystem::path LongPath(const std::filesystem::path& path);

// Creates or truncates a file, creating its parent directories if necessary.
// Returns false and writes a diagnostic if the file cannot be created.
bool TouchFile(const std::filesystem::path& path, std::ostream* stderr_stream);

// Returns true if the given path exists.
bool PathExists(absl::string_view path);

}  // namespace bazel_rules_swift

#endif  // BUILD_BAZEL_RULES_SWIFT_TOOLS_COMMON_FILE_SYSTEM_H_
